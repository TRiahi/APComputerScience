public interface Processing{
  
    public abstract void doReading(int p,String typeHomework);
    
}
