public class Equilateral
{
  
    public class printE(){
        
        System.out.println("");
        
    }
    
}
