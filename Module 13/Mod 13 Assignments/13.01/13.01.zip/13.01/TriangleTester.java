/**
 * Tests all the triangles classes
 * 
 * @author David Johnson
 * @version 1/22/15
 */
public class TriangleTester{
    
    public static void main(String[] args){
    
        Triangle varsT = new Triangle();
        Equilateral varsE = new Equilateral();
        IsoscelesRight varsI = new IsoscelesRight();
    
    }
    
}
